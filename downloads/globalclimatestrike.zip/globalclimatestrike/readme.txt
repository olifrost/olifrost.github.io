Let me know if there are any versions missing or if I can help with adapts.

The textured versions will generally look better on social, for decide for yourself if printing.

If time allows, please give a tag and a follow if you're sharing.

mail@olifro.st
@realolifrost
https://olifro.st/refrost
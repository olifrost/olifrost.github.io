Let me know if there are any versions missing or if I can help with adapts.

If you do print these, I'd love to see photos too. 

If time allows, please give a tag and a follow if you're sharing.

mail@olifro.st
@realolifrost
https://olifro.st/refrost